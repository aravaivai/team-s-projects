﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace Zakharov_hotel
{
    public partial class AdminWindow : Window
    {
        Database db = new Database();

        public AdminWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private string GetVal(DataRowView row, string name)
        {
            string n = name.ToLower();
            if (row.Row.Table.Columns.Contains(n)) return row[n].ToString();
            if (row.Row.Table.Columns.Contains(name)) return row[name].ToString();
            return "";
        }

        void LoadData()
        {
            try
            { 
                dgStaff.ItemsSource = null;

                DataTable dtStaff = db.ExecuteQuery("SELECT * FROM staff_view");

                if (dtStaff != null)
                {
                    dgStaff.ItemsSource = dtStaff.DefaultView;
                }

                DataTable dtPos = db.ExecuteQuery("SELECT \"PositionID\" as pid, \"Title\" as tit FROM \"Positions\"");
                cmbPositions.SelectedValuePath = "pid";
                cmbPositions.DisplayMemberPath = "tit";
                cmbPositions.ItemsSource = dtPos?.DefaultView;

                DataTable dtStaffForRooms = db.ExecuteQuery("SELECT \"EmployeeID\" as employeeid, \"FullName\" as fullname FROM \"Employees\"");
                cmbRoomEmployee.ItemsSource = dtStaffForRooms?.DefaultView;
                dgRoomsAdmin.ItemsSource = db.ExecuteQuery("SELECT * FROM rooms_view")?.DefaultView;

                dgServicesAdmin.ItemsSource = db.ExecuteQuery("SELECT * FROM \"Services\"")?.DefaultView;

                dgAllClients.ItemsSource = db.ExecuteQuery("SELECT * FROM \"Clients\"")?.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void DgStaff_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgStaff.SelectedItem is DataRowView row)
            {
                editName.Text = GetVal(row, "fullname");
                editAge.Text = GetVal(row, "age");
                editGender.Text = GetVal(row, "gender");
                editAddress.Text = GetVal(row, "address");
                editPhone.Text = GetVal(row, "phone");
                editPassport.Text = GetVal(row, "passportdata");
                editBonus.Text = GetVal(row, "bonus");

                object posId = row.Row.Table.Columns.Contains("positionid") ? row["positionid"] : row["PositionID"];
                cmbPositions.SelectedValue = posId;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (dgStaff.SelectedItem is DataRowView row && cmbPositions.SelectedValue != null)
            {
                try
                {
                    string empId = GetVal(row, "employeeid");
                    string posId = cmbPositions.SelectedValue.ToString();
                    string bonus = editBonus.Text.Replace(',', '.');

                    string query = $@"UPDATE ""Employees"" SET 
                        ""FullName"" = '{editName.Text}', 
                        ""Age"" = {editAge.Text}, 
                        ""Gender"" = '{editGender.Text}', 
                        ""Address"" = '{editAddress.Text}', 
                        ""Phone"" = '{editPhone.Text}', 
                        ""PassportData"" = '{editPassport.Text}', 
                        ""PositionID"" = {posId}, 
                        ""Bonus"" = {bonus} 
                        WHERE ""EmployeeID"" = {empId}";

                    db.ExecuteUpdate(query);
                    LoadData();
                    MessageBox.Show("Сотрудник обновлен!");
                }
                catch (Exception ex) { MessageBox.Show("Ошибка сохранения: " + ex.Message); }
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbPositions.SelectedValue == null) { MessageBox.Show("Выберите должность!"); return; }
            try
            {
                string posId = cmbPositions.SelectedValue.ToString();
                string query = $@"INSERT INTO ""Employees"" (""FullName"", ""Age"", ""Gender"", ""Address"", ""Phone"", ""PassportData"", ""PositionID"", ""Bonus"") 
                    VALUES ('{editName.Text}', {editAge.Text}, '{editGender.Text}', '{editAddress.Text}', '{editPhone.Text}', '{editPassport.Text}', {posId}, 0)";
                
                db.ExecuteUpdate(query);
                LoadData();
                MessageBox.Show("Сотрудник добавлен!");
            }
            catch (Exception ex) { MessageBox.Show("Ошибка добавления: " + ex.Message); }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgStaff.SelectedItem is DataRowView row)
            {
                string empId = GetVal(row, "employeeid");
                db.ExecuteUpdate($@"DELETE FROM ""Employees"" WHERE ""EmployeeID"" = {empId}");
                LoadData();
            }
        }

        // Логика номеров
        private void DgRoomsAdmin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgRoomsAdmin.SelectedItem is DataRowView row)
            {
                txtRoomName.Text = GetVal(row, "roomname");
                txtRoomCap.Text = GetVal(row, "capacity");
                txtRoomPrice.Text = GetVal(row, "price");

                cmbRoomEmployee.SelectedValue = GetVal(row, "employeeid");
            }
        }

        private void BtnAddRoom_Click(object sender, RoutedEventArgs e)
        {
            string price = txtRoomPrice.Text.Replace(',', '.');
            db.ExecuteUpdate($@"INSERT INTO ""Rooms"" (""RoomName"", ""Capacity"", ""Price"") VALUES ('{txtRoomName.Text}', {txtRoomCap.Text}, {price})");
            LoadData();
        }

        private void BtnEditRoom_Click(object sender, RoutedEventArgs e)
        {
            if (dgRoomsAdmin.SelectedItem is DataRowView row)
            {
                try
                {
                    string id = GetVal(row, "roomid");
                    string price = txtRoomPrice.Text.Replace(',', '.');

                    string empId = cmbRoomEmployee.SelectedValue != null ? cmbRoomEmployee.SelectedValue.ToString() : "NULL";

                    string query = $@"UPDATE ""Rooms"" SET 
                ""RoomName""='{txtRoomName.Text}', 
                ""Capacity""={txtRoomCap.Text}, 
                ""Price""={price}, 
                ""EmployeeID""={empId} 
                WHERE ""RoomID""={id}";

                    db.ExecuteUpdate(query);
                    LoadData();
                    MessageBox.Show("Данные номера обновлены!");
                }
                catch (Exception ex) { MessageBox.Show("Ошибка: " + ex.Message); }
            }
        }

        private void BtnDelRoom_Click(object sender, RoutedEventArgs e)
        {
            if (dgRoomsAdmin.SelectedItem is DataRowView row)
            {
                try {
                    db.ExecuteUpdate($@"DELETE FROM ""Rooms"" WHERE ""RoomID""={GetVal(row, "RoomID")}");
                    LoadData();
                } catch { MessageBox.Show("Ошибка удаления!"); }
            }
        }

        // Логика услуг
        private void DgServicesAdmin_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgServicesAdmin.SelectedItem is DataRowView row)
            {
                txtServName.Text = GetVal(row, "ServiceName");
                txtServPrice.Text = GetVal(row, "Price");
            }
        }

        private void BtnAddServ_Click(object sender, RoutedEventArgs e)
        {
            string price = txtServPrice.Text.Replace(',', '.');
            db.ExecuteUpdate($@"INSERT INTO ""Services"" (""ServiceName"", ""Price"") VALUES ('{txtServName.Text}', {price})");
            LoadData();
        }

        private void BtnEditServ_Click(object sender, RoutedEventArgs e)
        {
            if (dgServicesAdmin.SelectedItem is DataRowView row)
            {
                string id = GetVal(row, "ServiceID");
                string price = txtServPrice.Text.Replace(',', '.');
                db.ExecuteUpdate($@"UPDATE ""Services"" SET ""ServiceName""='{txtServName.Text}', ""Price""={price} WHERE ""ServiceID""={id}");
                LoadData();
            }
        }

        private void BtnDelServ_Click(object sender, RoutedEventArgs e)
        {
            if (dgServicesAdmin.SelectedItem is DataRowView row)
            {
                db.ExecuteUpdate($@"DELETE FROM ""Services"" WHERE ""ServiceID""={GetVal(row, "ServiceID")}");
                LoadData();
            }
        }

        private void BtnDeleteBooking_Click(object sender, RoutedEventArgs e)
        {
            if (dgAllClients.SelectedItem is DataRowView row)
            {
                db.ExecuteUpdate($@"DELETE FROM ""Clients"" WHERE ""ClientID"" = {GetVal(row, "clientid")}");
                LoadData();
            }
        }
    }
}